# Disease-Prediction-using-machine-learning
Disease Prediction is based on the supervised learning and naïve bayes algorithm which predicts the disease, Based on the symptoms inputted by the user, the project is uses tkinter for GUI application, numpy and pandas.
Login Page of GUI:-
![image](https://user-images.githubusercontent.com/77828414/192148003-8a3f6b24-89b2-472c-9fd8-319771750ceb.png)

Disease Predictor Page:-
![image](https://user-images.githubusercontent.com/77828414/192147948-3f0cc46f-20bd-4320-b903-00551c8ee7f7.png)


Source-1
The dataset for this problem used with the main.py script is downloaded from here:

https://www.kaggle.com/kaushil268/disease-prediction-using-machine-learning
This dataset has 133 total columns, 132 of them being symptoms experienced by patiend and last column in prognosis for the same.

Source-2
The dataset for this problem used with the Jupyter notebook is downloaded from here:

https://impact.dbmi.columbia.edu/~friedma/Projects/DiseaseSymptomKB/index.html


Base Paper:-
https://ieeexplore.ieee.org/document/9154130
